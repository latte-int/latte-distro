#! /bin/sh
echo "#################################"
echo "Checking count --irr --exp --maxdet=1000"
echo "#################################"
./test.pl "--irr --exp --maxdet=1000"

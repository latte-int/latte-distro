October 21, 2007

The version cdd+-077a is a slight update of cdd+-077 that is easier to compile
with gcc/g++ version 4 or higher.  Changes are only with the gmp wrapper developed
by the Polymake team and setoper.C.

Please report problems to 

  Komei Fukuda <fukuda@ifor.math.ethz.ch>. 

Thanks.  Komei Fukuda

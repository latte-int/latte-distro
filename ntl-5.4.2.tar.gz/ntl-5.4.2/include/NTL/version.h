
#ifndef NTL_version__H
#define NTL_version__H

#define NTL_VERSION "5.4.2"

#define NTL_MAJOR_VERSION  (5)
#define NTL_MINOR_VERSION  (4)
#define NTL_REVISION       (2)

#endif



#include <NTL/vec_ZZVec.h>

#include <NTL/new.h>

NTL_START_IMPL

NTL_vector_impl(ZZVec,vec_ZZVec)

NTL_END_IMPL

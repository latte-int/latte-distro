/* glpcfg.h (glpk configuration file) */

/*----------------------------------------------------------------------
-- This code is part of GNU Linear Programming Kit (GLPK).
--
-- Copyright (C) 2000, 01, 02, 03, 04, 05, 06 Andrew Makhorin,
-- Department for Applied Informatics, Moscow Aviation Institute,
-- Moscow, Russia. All rights reserved. E-mail: <mao@mai2.rcnet.ru>.
--
-- GLPK is free software; you can redistribute it and/or modify it
-- under the terms of the GNU General Public License as published by
-- the Free Software Foundation; either version 2, or (at your option)
-- any later version.
--
-- GLPK is distributed in the hope that it will be useful, but WITHOUT
-- ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
-- or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public
-- License for more details.
--
-- You should have received a copy of the GNU General Public License
-- along with GLPK; see the file COPYING. If not, write to the Free
-- Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
-- 02110-1301, USA.
----------------------------------------------------------------------*/

#ifndef _GLPCFG_H
#define _GLPCFG_H

#undef GLP_HUGE_MEM
/* define this symbol to enable using an alternative version of
   umalloc/ucalloc/ufree, which does not limit the amount of allocated
   memory to INT_MAX bytes */

#undef GLP_USE_GMP
/* define this symbol to enable using the GNU MP library rather than
   the GLPK bignum module; it is highly recommended to use the GNU MP
   library, if possible, to attain a much better performance */

#endif

/* eof */

#! /bin/sh
echo "#################################"
echo "Checking count (with defaults)..."
echo "#################################"
./test.pl ""

int normalize_main(int argc, char **argv);

int main(int argc, char **argv)
{
  return normalize_main(argc, argv);
}


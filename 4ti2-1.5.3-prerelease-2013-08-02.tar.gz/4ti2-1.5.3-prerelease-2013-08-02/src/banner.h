#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#define FORTY_TWO_BANNER \
"-------------------------------------------------\n\
4ti2 version " PACKAGE_VERSION ", Copyright (C) 2006 4ti2 team.\n\
4ti2 comes with ABSOLUTELY NO WARRANTY.\n\
This is free software, and you are welcome\n\
to redistribute it under certain conditions.\n\
For details, see the file COPYING.\n\
-------------------------------------------------\n\
"
